from django.urls import path,include
from . import views


urlpatterns = [
    path('owner_dashboard/',views.owner_dashboard,name='owner_dashboard'),
    path('add_station/', views.add_station, name='add_station'),
    
    
]