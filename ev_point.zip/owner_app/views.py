from django.shortcuts import render, redirect
from .models import EVStation
from home.models import OwnerProfile

# ==================================================
# EV Point - Owner Module Views
# Handles owner dashboard and charging station management
# ==================================================

# ==================================================
# Owner Dashboard View
# Displays dashboard for authenticated station owners
# ==================================================
def owner_dashboard(request):

    # Allow access only to logged-in owners
    if not request.user.is_authenticated:

        return redirect('owner_login')

    # Render owner dashboard page
    return render(
        request,
        'owner_app/owner_dashboard.html'
    )

# ==================================================
# Add Station View
# Creates a new EV charging station for the owner
# ==================================================
def add_station(request):

    # Process station registration form submission
    if request.method == "POST":

        # Retrieve logged-in owner's profile
        owner = OwnerProfile.objects.get(user=request.user)

        # Collect station details from submitted form
        station_name = request.POST.get('station_name')
        city = request.POST.get('city')
        station_type = request.POST.get('station_type')
        total_slots = request.POST.get('total_slots')
        rate_per_unit = request.POST.get('rate_per_unit')
        phone_number = request.POST.get('phone_number')

        # Create and save EV station record
        EVStation.objects.create(
            owner=owner,
            station_name=station_name,
            city=city,
            station_type=station_type,
            total_slots=total_slots,
            rate_per_unit=rate_per_unit,
            phone_number=phone_number
        )

        # Redirect to dashboard after successful creation
        return redirect('owner_dashboard')

    # Display add station form page
    return render(request, 'owner_app/add_station.html')