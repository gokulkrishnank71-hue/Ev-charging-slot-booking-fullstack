from django.contrib import admin
from .models import Booking


@admin.register(Booking)
class BookingAdmin(admin.ModelAdmin):
    list_display = ('user', 'station', 'date', 'slot_name', 'start_time', 'end_time', 'created_at')
    list_filter = ('date', 'station')
    search_fields = ('user__username', 'station__station_name', 'slot_name')
