from django.conf import settings
from django.db import models
from owner_app.models import EVStation

# ==================================================
# EV Point - Booking Models
# Stores EV charging slot reservations made by users
# ==================================================

# ==================================================
# Booking Model
# Represents a charging slot reservation for a station
# ==================================================
class Booking(models.Model):
    # User who made the booking
    user = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE
    )
    # EV charging station selected for booking
    station = models.ForeignKey(
        EVStation,
        on_delete=models.CASCADE
    )
    # Booking date
    date = models.DateField()
    # Name of the selected charging slot
    slot_name = models.CharField(max_length=50)
    # Slot start time
    start_time = models.CharField(max_length=20)
    # Slot end time
    end_time = models.CharField(max_length=20)
    # Timestamp when booking was created
    created_at = models.DateTimeField(auto_now_add=True)

    # Booking model configuration
    class Meta:
        # Prevent duplicate bookings for the same station, date, and slot
        unique_together = ('station', 'date', 'slot_name')
        # Display latest bookings first
        ordering = ['-date', 'slot_name']

    # Return readable booking information for admin display
    def __str__(self):
        return f'{self.user} - {self.station} - {self.date} - {self.slot_name}'
