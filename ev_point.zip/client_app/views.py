import datetime
import json

# ==================================================
# EV Point - Client Module Views
# Handles station search, booking management, and dashboard operations
# ==================================================

from django.contrib import messages
from django.shortcuts import render, get_object_or_404, redirect

from owner_app.models import EVStation
from .models import Booking

# ==================================================
# Charging Slot Time Generation
# Creates hourly charging slots from 6 AM to 6 AM next day
# ==================================================

SLOT_TIMES = []
for h in range(6, 30):
    start_hour = h % 24
    end_hour = (h + 1) % 24
    period_start = 'AM' if start_hour < 12 else 'PM'
    period_end = 'AM' if end_hour < 12 else 'PM'
    display_start = 12 if start_hour % 12 == 0 else start_hour % 12
    display_end = 12 if end_hour % 12 == 0 else end_hour % 12
    SLOT_TIMES.append({
        'slot_name': f'Slot {len(SLOT_TIMES) + 1}',
        'start_time': f'{display_start:02d}:00 {period_start}',
        'end_time': f'{display_end:02d}:00 {period_end}',
        'time': f'{display_start:02d}:00 {period_start} - {display_end:02d}:00 {period_end}',
    })

# ==================================================
# Client Dashboard View
# Displays the main dashboard for EV Point clients
# ==================================================
def client_dashboard(request):

    return render(request,'client_dashboard.html' )

# ==================================================
# Membership Plans View
# Displays available subscription plans for users
# ==================================================
def plans_list(request):
    return render(request,'plans_list.html',name='plans_list')

# ==================================================
# Station Search View
# Displays all active EV charging stations
# ==================================================
def station_search(request):

    # Retrieve all active charging stations
    stations = EVStation.objects.filter(

        is_active=True

    )

    return render(

        request,

        'station_search.html',

        {

            'stations': stations
 
        }
    )


# ==================================================
# Book Charging Slot View
# Handles slot booking and availability management
# ==================================================
def book_now(request, station_id):
    # Retrieve selected charging station
    station = get_object_or_404(EVStation, station_id=station_id)
    # Generate next 7 booking dates
    today = datetime.date.today()
    date_list = [today + datetime.timedelta(days=i) for i in range(7)]
    # Fetch existing bookings for selected dates
    booked_slots = Booking.objects.filter(station=station, date__in=date_list)
    booked_lookup = {(booking.date, booking.slot_name): booking for booking in booked_slots}

    # Process booking form submission
    if request.method == 'POST':
        # Ensure user is logged in before booking
        if not request.user.is_authenticated:
            messages.error(request, 'Please login to book a slot.')
            return redirect('client_dashboard')

        # Retrieve selected slot details from form
        selected_date = request.POST.get('selected_date')
        selected_slot = request.POST.get('selected_slot')
        selected_start = request.POST.get('selected_start')
        selected_end = request.POST.get('selected_end')

        if not selected_date or not selected_slot:
            messages.error(request, 'Choose a date and slot before booking.')
            return redirect('book_now', station_id=station_id)

        # Validate booking date format
        try:
            booking_date = datetime.datetime.strptime(selected_date, '%Y-%m-%d').date()
        except ValueError:
            messages.error(request, 'Invalid booking date.')
            return redirect('book_now', station_id=station_id)

        # Prevent duplicate slot bookings
        if Booking.objects.filter(station=station, date=booking_date, slot_name=selected_slot).exists():
            messages.error(request, 'This slot is already booked. Please choose another slot.')
            return redirect('book_now', station_id=station_id)

        # Create new booking record
        Booking.objects.create(
            user=request.user,
            station=station,
            date=booking_date,
            slot_name=selected_slot,
            start_time=selected_start or '',
            end_time=selected_end or '',
        )

        # Display booking confirmation message
        messages.success(request, f'Booked {selected_slot} for {booking_date.strftime("%d %b %Y")} successfully.')
        return redirect('book_now', station_id=station_id)

    # Prepare slot availability data for frontend display
    slots_json = []
    for date in date_list:
        day_slots = []
        for slot in SLOT_TIMES:
            status = 'booked' if (date, slot['slot_name']) in booked_lookup else 'available'
            day_slots.append({
                'slot_name': slot['slot_name'],
                'time': slot['time'],
                'start_time': slot['start_time'],
                'end_time': slot['end_time'],
                'status': status,
            })
        slots_json.append(day_slots)

    # Render booking page with slot information
    return render(request, 'book_now.html', {
        'station': station,
        'slots_json': json.dumps(slots_json),
        'start_date': today.isoformat(),
    })